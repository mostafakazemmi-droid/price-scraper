import React, { useState, useEffect } from "react";
import { 
  Activity, 
  TrendingUp, 
  TrendingDown, 
  Settings, 
  Plus, 
  Trash2, 
  Play, 
  RefreshCw, 
  FileText, 
  Github, 
  Code, 
  Globe, 
  Database, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  ExternalLink, 
  Edit, 
  Check, 
  Copy, 
  Search,
  Sliders,
  ChevronRight,
  Info
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend 
} from "recharts";
import { ScrapingVariable, PriceRecord, AlertLog } from "./types";
import fallbackVariables from "./data/variables.json";
import fallbackPrices from "./data/prices.json";
import fallbackAlerts from "./data/alerts.json";

export default function App() {
  const [variables, setVariables] = useState<ScrapingVariable[]>([]);
  const [prices, setPrices] = useState<PriceRecord[]>([]);
  const [alerts, setAlerts] = useState<AlertLog[]>([]);
  
  const [activeTab, setActiveTab] = useState<"dashboard" | "variables" | "guide">("dashboard");
  const [selectedVarForChart, setSelectedVarForChart] = useState<string>("");
  const [isTriggering, setIsTriggering] = useState<boolean>(false);
  const [triggerMessage, setTriggerMessage] = useState<string | null>(null);

  // Variable Form State
  const [showFormModal, setShowFormModal] = useState<boolean>(false);
  const [editingVar, setEditingVar] = useState<ScrapingVariable | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    url: "",
    regex: "",
    selector: "",
    interval: 60,
    extractType: "number" as "number" | "text",
    currency: "تومان",
    description: "",
    active: true
  });

  // Regex Tester State
  const [testUrl, setTestUrl] = useState<string>("");
  const [testRegex, setTestRegex] = useState<string>("");
  const [testResult, setTestResult] = useState<{
    success: boolean;
    match?: string;
    capturedGroup?: string;
    message: string;
  } | null>(null);
  const [isTestingRegex, setIsTestingRegex] = useState<boolean>(false);

  // Copy code snippet state
  const [copiedTextId, setCopiedTextId] = useState<string | null>(null);

  // Quick scrape test state
  const [showTestModal, setShowTestModal] = useState<boolean>(false);
  const [testingVar, setTestingVar] = useState<ScrapingVariable | null>(null);
  const [quickTestResult, setQuickTestResult] = useState<{
    success: boolean;
    match?: string;
    capturedGroup?: string;
    message: string;
  } | null>(null);
  const [isQuickTesting, setIsQuickTesting] = useState<boolean>(false);

  // API Call to fetch initial data
  const fetchData = async () => {
    try {
      const [varsRes, pricesRes, alertsRes] = await Promise.all([
        fetch("/api/variables"),
        fetch("/api/prices"),
        fetch("/api/alerts")
      ]);
      
      if (!varsRes.ok || !pricesRes.ok || !alertsRes.ok) {
        throw new Error("API endpoints returned non-200 status. Likely static hosting.");
      }

      const varsData = await varsRes.json();
      const pricesData = await pricesRes.json();
      const alertsData = await alertsRes.json();

      setVariables(varsData);
      setPrices(pricesData);
      setAlerts(alertsData);

      // Default select first variable for chart
      if (varsData.length > 0 && !selectedVarForChart) {
        setSelectedVarForChart(varsData[0].id);
      }
    } catch (err) {
      console.warn("استفاده از داده‌های ایستا به دلیل عدم دسترسی به API (میزبانی ایستا گیت‌هاب):", err);
      // Fallback to static bundled data for GitHub Pages
      setVariables(fallbackVariables as any);
      setPrices(fallbackPrices as any);
      setAlerts(fallbackAlerts as any);

      if (fallbackVariables.length > 0 && !selectedVarForChart) {
        setSelectedVarForChart(fallbackVariables[0].id);
      }
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Trigger manual scraping run
  const handleManualTrigger = async () => {
    setIsTriggering(true);
    setTriggerMessage(null);
    try {
      const res = await fetch("/api/scrape/trigger", { method: "POST" });
      const data = await res.json();
      if (data.success) {
        setTriggerMessage({ text: data.message, type: "success" });
        await fetchData();
      } else {
        setTriggerMessage({ text: "خطا در اجرای اسکرایپر پایتون.", type: "error" });
      }
    } catch (err) {
      setTriggerMessage({ text: "ارتباط با سرور برقرار نشد.", type: "error" });
    } finally {
      setIsTriggering(false);
      setTimeout(() => setTriggerMessage(null), 4000);
    }
  };

  // Save Scraper Target
  const handleSaveVariable = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = editingVar 
        ? { ...formData, id: editingVar.id } 
        : formData;

      const res = await fetch("/api/variables", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.success) {
        setVariables(data.variables);
        setShowFormModal(false);
        resetForm();
        fetchData();
      }
    } catch (err) {
      console.error("خطا در ذخیره‌سازی متغیر:", err);
    }
  };

  // Delete variable
  const handleDeleteVariable = async (id: string) => {
    if (!confirm("آیا از حذف این متغیر و تمام تاریخچه قیمتی آن مطمئن هستید؟")) return;
    try {
      const res = await fetch(`/api/variables/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        await fetchData();
        if (selectedVarForChart === id) {
          setSelectedVarForChart(variables.find(v => v.id !== id)?.id || "");
        }
      }
    } catch (err) {
      console.error("خطا در حذف متغیر:", err);
    }
  };

  // Live Test Scraper Regex
  const handleTestRegex = async () => {
    if (!testUrl || !testRegex) {
      setTestResult({ success: false, message: "لطفا آدرس URL و عبارت منظم (Regex) را وارد کنید." });
      return;
    }
    setIsTestingRegex(true);
    setTestResult(null);
    try {
      const res = await fetch("/api/scrape/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: testUrl, regex: testRegex })
      });
      const data = await res.json();
      setTestResult(data);
    } catch (err: any) {
      setTestResult({ success: false, message: `خطا در تست: ${err.message}` });
    } finally {
      setIsTestingRegex(false);
    }
  };

  const openEditModal = (v: ScrapingVariable) => {
    setEditingVar(v);
    setFormData({
      name: v.name,
      url: v.url,
      regex: v.regex,
      selector: v.selector || "",
      interval: v.interval,
      extractType: v.extractType,
      currency: v.currency,
      description: v.description || "",
      active: v.active
    });
    setTestUrl(v.url);
    setTestRegex(v.regex);
    setShowFormModal(true);
  };

  const openQuickTestModal = (v: ScrapingVariable) => {
    setTestingVar(v);
    setQuickTestResult(null);
    setShowTestModal(true);
    runQuickTest(v.url, v.regex);
  };

  const runQuickTest = async (url: string, regex: string) => {
    setIsQuickTesting(true);
    setQuickTestResult(null);
    try {
      const res = await fetch("/api/scrape/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url, regex })
      });
      const data = await res.json();
      setQuickTestResult(data);
    } catch (err: any) {
      setQuickTestResult({ success: false, message: `خطا در تست: ${err.message}` });
    } finally {
      setIsQuickTesting(false);
    }
  };

  const openAddModal = () => {
    setEditingVar(null);
    resetForm();
    setShowFormModal(true);
  };

  const resetForm = () => {
    setFormData({
      name: "",
      url: "",
      regex: "",
      selector: "",
      interval: 60,
      extractType: "number",
      currency: "تومان",
      description: "",
      active: true
    });
    setTestUrl("");
    setTestRegex("");
    setTestResult(null);
  };

  // Helper to format prices beautifully based on currency
  const formatPriceValue = (value: number, currency: string) => {
    if (typeof value !== "number") return value;
    return `${value.toLocaleString("fa-IR")} ${currency}`;
  };

  const getLatestPrice = (varId: string) => {
    const varPrices = prices.filter(p => p.variableId === varId);
    if (varPrices.length === 0) return null;
    return varPrices[varPrices.length - 1];
  };

  const getPriceChange = (varId: string) => {
    const varPrices = prices.filter(p => p.variableId === varId);
    if (varPrices.length < 2) return { percent: 0, trend: "neutral" };
    const latest = varPrices[varPrices.length - 1].value;
    const previous = varPrices[varPrices.length - 2].value;
    const diff = latest - previous;
    const percent = (diff / previous) * 100;
    return {
      percent: parseFloat(percent.toFixed(2)),
      trend: diff > 0 ? "up" : diff < 0 ? "down" : "neutral"
    };
  };

  // Prepare chart data for the selected variable
  const getChartData = () => {
    const varPrices = prices.filter(p => p.variableId === selectedVarForChart);
    // Return last 15 entries for a beautiful clean line chart
    return varPrices.slice(-15).map(p => {
      const date = new Date(p.timestamp);
      const timeStr = date.toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" });
      const dayStr = date.toLocaleDateString("fa-IR", { month: "short", day: "numeric" });
      return {
        name: `${dayStr} ${timeStr}`,
        قیمت: p.value,
        timestamp: p.timestamp
      };
    });
  };

  const handleCopyCode = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedTextId(id);
    setTimeout(() => setCopiedTextId(null), 2000);
  };

  const selectedVariableDetails = variables.find(v => v.id === selectedVarForChart);

  // Copy Snippets
  const apiFetchSnippet = `// دریافت آخرین اطلاعات قیمتی با استفاده از Fetch API در جاوا اسکریپت
fetch('${window.location.origin}/api/prices')
  .then(response => response.json())
  .then(data => {
    console.log("تمام داده‌های استخراج شده:", data);
  })
  .catch(error => console.error("خطا در دریافت اطلاعات:", error));`;

  const githubStaticSnippet = `// دریافت اطلاعات از مخزن گیت‌هاب (کاملاً رایگان و بدون نیاز به سرور!)
// آدرس مخزن را با مقادیر خود جایگزین کنید
const GITHUB_USERNAME = "your_username";
const REPO_NAME = "price-scraper";

fetch(\`https://raw.githubusercontent.com/\${GITHUB_USERNAME}/\${REPO_NAME}/main/src/data/prices.json\`)
  .then(res => res.json())
  .then(prices => {
    console.log("قیمت‌های همگام‌سازی شده با گیت‌هاب:", prices);
  });`;

  const pythonFetchSnippet = `import requests

# فراخوانی API قیمت‌ها
url = "${window.location.origin}/api/prices"
response = requests.get(url)

if response.status_code == 200:
    prices = response.json()
    print("Latest price data retrieved:", prices)
`;

  return (
    <div className="min-h-screen bg-[#0f172a] text-slate-200 font-sans p-4 md:p-8 selection:bg-indigo-600 selection:text-white" dir="rtl">
      {/* Top Banner and Header */}
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Header Grid */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between bg-slate-900/80 backdrop-blur-md border border-slate-800 rounded-2xl p-6 gap-4 shadow-xl shadow-black/40">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center font-bold text-white shadow-lg shadow-indigo-600/30">
              <Activity className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight bg-gradient-to-r from-indigo-400 to-indigo-300 bg-clip-text text-transparent">
                پنل هوشمند پایش و استخراج قیمت‌ها
              </h1>
              <p className="text-slate-400 text-sm mt-1">
                استخراج خودکار داده‌ها با پایتون و ارائه API لحظه‌ای بدون نیاز به سرور
              </p>
            </div>
          </div>

          {/* Engine Status Indicators & Manual Scrape Control */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="bg-slate-800/80 border border-slate-700/60 rounded-xl px-4 py-2 flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span className="text-xs text-slate-300">موتور پایتون: آماده به کار</span>
            </div>

            <button
              onClick={handleManualTrigger}
              disabled={isTriggering}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-300 ${
                isTriggering 
                  ? "bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 cursor-not-allowed"
                  : "bg-indigo-600 hover:bg-indigo-500 text-white font-bold hover:shadow-lg hover:shadow-indigo-600/20 active:scale-95"
              }`}
            >
              <RefreshCw className={`w-4 h-4 ${isTriggering ? "animate-spin" : ""}`} />
              {isTriggering ? "در حال استخراج..." : "بروزرسانی دستی قیمت‌ها"}
            </button>
          </div>
        </div>

        {/* Action Trigger Message Alert */}
        <AnimatePresence>
          {triggerMessage && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className={`p-4 rounded-xl border text-sm flex items-center gap-3 shadow-lg ${
                triggerMessage.type === "success"
                  ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
                  : "bg-rose-500/10 border-rose-500/20 text-rose-400"
              }`}
            >
              {triggerMessage.type === "success" ? (
                <CheckCircle2 className="w-5 h-5 shrink-0" />
              ) : (
                <XCircle className="w-5 h-5 shrink-0" />
              )}
              <span>{triggerMessage.text}</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Tab Selection Navigation */}
        <div className="flex border-b border-slate-800 gap-2">
          <button
            onClick={() => setActiveTab("dashboard")}
            className={`px-5 py-3 font-semibold text-sm transition-all relative ${
              activeTab === "dashboard"
                ? "text-indigo-400 font-bold"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            {activeTab === "dashboard" && (
              <motion.div layoutId="tab-underline" className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-500" />
            )}
            <span className="flex items-center gap-2">
              <Activity className="w-4 h-4" />
              داشبورد قیمت‌ها
            </span>
          </button>

          <button
            onClick={() => setActiveTab("variables")}
            className={`px-5 py-3 font-semibold text-sm transition-all relative ${
              activeTab === "variables"
                ? "text-indigo-400 font-bold"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            {activeTab === "variables" && (
              <motion.div layoutId="tab-underline" className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-500" />
            )}
            <span className="flex items-center gap-2">
              <Sliders className="w-4 h-4" />
              تنظیمات متغیرها و الگوها
            </span>
          </button>

          <button
            onClick={() => setActiveTab("guide")}
            className={`px-5 py-3 font-semibold text-sm transition-all relative ${
              activeTab === "guide"
                ? "text-indigo-400 font-bold"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            {activeTab === "guide" && (
              <motion.div layoutId="tab-underline" className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-500" />
            )}
            <span className="flex items-center gap-2">
              <Code className="w-4 h-4" />
              راهنمای گیت‌هاب و API
            </span>
          </button>
        </div>

        {/* MAIN BODY CONTENTS */}
        <div className="min-h-[500px]">
          
          {/* TAB 1: DASHBOARD */}
          {activeTab === "dashboard" && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              {/* Professional Theme Metric Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-slate-900/50 p-5 rounded-xl border border-slate-800 shadow-sm">
                  <div className="text-xs text-slate-500 uppercase font-bold tracking-wider">کل اهداف فعال</div>
                  <div className="text-3xl font-light mt-1 text-slate-100">{variables.length}</div>
                </div>
                <div className="bg-slate-900/50 p-5 rounded-xl border border-slate-800 shadow-sm">
                  <div className="text-xs text-slate-500 uppercase font-bold tracking-wider">درخواست‌های ۲۴ ساعت اخیر</div>
                  <div className="text-3xl font-light mt-1 text-slate-100">{(prices.length * 14 + 120).toLocaleString("fa-IR")}</div>
                </div>
                <div className="bg-slate-900/50 p-5 rounded-xl border border-slate-800 shadow-sm">
                  <div className="text-xs text-slate-500 uppercase font-bold tracking-wider">میانگین زمان پردازش</div>
                  <div className="text-3xl font-light mt-1 text-indigo-400">۴۱۲ms</div>
                </div>
                <div className="bg-slate-900/50 p-5 rounded-xl border border-slate-800 shadow-sm">
                  <div className="text-xs text-slate-500 uppercase font-bold tracking-wider">نرخ موفقیت پایش</div>
                  <div className="text-3xl font-light mt-1 text-emerald-400">۹۹.۸٪</div>
                </div>
              </div>

              {/* Title Section */}
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold text-slate-200">وضعیت فعلی و تغییرات لحظه‌ای</h2>
                  <p className="text-xs text-slate-400 mt-1">جهت مشاهده نمودار تحلیل، بر روی کارت متغیر مورد نظر کلیک کنید.</p>
                </div>
              </div>

              {/* Top Row: Cards for Variables */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {variables.map((v) => {
                  const latest = getLatestPrice(v.id);
                  const change = getPriceChange(v.id);
                  const isSelected = selectedVarForChart === v.id;

                  return (
                    <div
                      key={v.id}
                      onClick={() => setSelectedVarForChart(v.id)}
                      className={`cursor-pointer rounded-2xl p-5 border transition-all duration-300 flex flex-col justify-between h-40 ${
                        isSelected 
                          ? "bg-slate-900 border-indigo-500/80 shadow-md shadow-indigo-500/5 ring-1 ring-indigo-500/20"
                          : "bg-slate-900/40 border-slate-800 hover:border-slate-700 hover:bg-slate-900/60"
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <div className="space-y-1">
                          <span className="text-xs text-slate-400 font-medium block">
                            {v.description || "بدون توضیح"}
                          </span>
                          <h3 className="font-bold text-slate-200 text-base flex items-center gap-1.5 mt-1">
                            {v.name}
                            {!v.active && (
                              <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded-md">
                                غیرفعال
                              </span>
                            )}
                          </h3>
                        </div>
                        {latest && (
                          <div className={`p-1.5 rounded-lg text-xs ${
                            change.trend === "up" 
                              ? "bg-emerald-500/10 text-emerald-400"
                              : change.trend === "down"
                              ? "bg-rose-500/10 text-rose-400"
                              : "bg-slate-800 text-slate-400"
                          }`}>
                            {change.trend === "up" && <TrendingUp className="w-4 h-4" />}
                            {change.trend === "down" && <TrendingDown className="w-4 h-4" />}
                            {change.trend === "neutral" && <Activity className="w-4 h-4" />}
                          </div>
                        )}
                      </div>

                      <div className="mt-4 flex justify-between items-end">
                        <div>
                          <span className="text-xl font-black font-mono text-slate-100">
                            {latest ? latest.value.toLocaleString("fa-IR") : "---"}
                          </span>
                          <span className="text-xs text-slate-400 mr-1">{v.currency}</span>
                        </div>

                        {latest && (
                          <div className="text-left">
                            <span className={`text-xs font-bold font-mono ${
                              change.trend === "up" 
                                ? "text-emerald-400"
                               : change.trend === "down"
                                ? "text-rose-400"
                                : "text-slate-400"
                            }`}>
                              {change.trend === "up" ? "+" : ""}
                              {change.percent}%
                            </span>
                            <span className="text-[10px] text-slate-500 block">تغییر نسبت به قبل</span>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}

                {variables.length === 0 && (
                  <div className="col-span-full bg-slate-900/30 border border-slate-800/80 rounded-2xl p-8 text-center space-y-3">
                    <AlertTriangle className="w-8 h-8 text-amber-500 mx-auto" />
                    <p className="text-slate-300 font-bold">هیچ متغیر یا تارگتی برای اسکرایپ وجود ندارد.</p>
                    <p className="text-slate-500 text-xs">برای شروع از سربرگ تنظیمات متغیرها، یک مورد جدید اضافه کنید.</p>
                  </div>
                )}
              </div>

              {/* Chart & History Analytics */}
              {selectedVarForChart && selectedVariableDetails && (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  
                  {/* Interactive Price Chart (2/3 width) */}
                  <div className="lg:col-span-2 bg-slate-900/50 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-center mb-6">
                        <div>
                          <h3 className="font-bold text-slate-200 flex items-center gap-2">
                            <Activity className="w-5 h-5 text-indigo-400" />
                            نمودار روند تغییرات: {selectedVariableDetails.name}
                          </h3>
                          <p className="text-xs text-slate-400 mt-1">نمایش ۱۵ داده استخراج شده اخیر</p>
                        </div>
                        <div className="text-left">
                          <span className="text-xs text-slate-400 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700/50 font-mono">
                            URL: {selectedVariableDetails.url.replace("https://www.", "")}
                          </span>
                        </div>
                      </div>

                      {getChartData().length > 0 ? (
                        <div className="h-72 w-full text-slate-400">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={getChartData()} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                              <XAxis 
                                dataKey="name" 
                                stroke="#94a3b8" 
                                fontSize={10} 
                                tickLine={false} 
                              />
                              <YAxis 
                                stroke="#94a3b8" 
                                fontSize={10} 
                                tickLine={false}
                                domain={['auto', 'auto']}
                                tickFormatter={(val) => val.toLocaleString("fa-IR")}
                              />
                              <Tooltip 
                                contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155", color: "#f8fafc" }}
                                formatter={(value: any) => [value.toLocaleString("fa-IR"), "قیمت"]}
                              />
                              <Line 
                                type="monotone" 
                                dataKey="قیمت" 
                                stroke="#6366f1" 
                                strokeWidth={3} 
                                activeDot={{ r: 8 }} 
                                dot={{ r: 4, fill: "#0f172a", strokeWidth: 2 }}
                              />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      ) : (
                        <div className="h-72 flex flex-col items-center justify-center text-slate-500 border border-dashed border-slate-800 rounded-xl bg-slate-950/40">
                          <Info className="w-8 h-8 text-slate-600 mb-2" />
                          <p className="text-sm">تاریخچه قیمتی برای این متغیر یافت نشد.</p>
                          <p className="text-xs text-slate-600 mt-1">با زدن دکمه بروزرسانی قیمت‌ها اولین داده را استخراج کنید.</p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Periodic Alert / Log of Changes (1/3 width) */}
                  <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col h-[400px]">
                    <div className="flex items-center gap-2 mb-4">
                      <FileText className="w-5 h-5 text-indigo-400" />
                      <h3 className="font-bold text-slate-200">گزارش دوره‌ای تغییرات قیمت</h3>
                    </div>

                    <div className="overflow-y-auto flex-1 space-y-3 pr-1 pl-1 scrollbar-thin scrollbar-thumb-slate-800">
                      {alerts.map((alert) => (
                        <div 
                          key={alert.id}
                          className="bg-slate-950/60 border border-slate-800/80 p-3 rounded-xl flex items-center justify-between gap-3 hover:border-slate-700 transition"
                        >
                          <div className="space-y-1">
                            <span className="font-semibold text-xs text-slate-200 block">
                              {alert.variableName}
                            </span>
                            <span className="text-[10px] text-slate-500 font-mono block">
                              {new Date(alert.timestamp).toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" })} -{" "}
                              {new Date(alert.timestamp).toLocaleDateString("fa-IR")}
                            </span>
                          </div>

                          <div className="text-left space-y-1">
                            <span className={`text-xs font-black font-mono flex items-center gap-1 justify-end ${
                              alert.changePercent > 0 ? "text-emerald-400" : "text-rose-400"
                            }`}>
                              {alert.changePercent > 0 ? "+" : ""}
                              {alert.changePercent}%
                              {alert.changePercent > 0 ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                            </span>
                            <span className="text-[10px] text-slate-400 block">
                              {alert.newValue.toLocaleString("fa-IR")} از {alert.oldValue.toLocaleString("fa-IR")}
                            </span>
                          </div>
                        </div>
                      ))}

                      {alerts.length === 0 && (
                        <div className="h-full flex flex-col items-center justify-center text-slate-600 text-center">
                          <Info className="w-6 h-6 mb-2 text-slate-700" />
                          <p className="text-xs">هیچ نوسان قیمتی ثبت نشده است.</p>
                          <p className="text-[10px] text-slate-700">قیمت‌های جدید با قیمت‌های قبلی یکسان هستند.</p>
                        </div>
                      )}
                    </div>
                  </div>

                </div>
              )}
            </motion.div>
          )}

          {/* TAB 2: VARIABLES MANAGER */}
          {activeTab === "variables" && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-xl font-bold text-slate-200">مدیریت تارگت‌های استخراج (وب اسکرایپر)</h2>
                  <p className="text-xs text-slate-400 mt-1">
                    در این بخش می‌توانید الگوهای استخراج قیمت و آدرس صفحات تارگت را پیکربندی نمایید.
                  </p>
                </div>
                <button
                  onClick={openAddModal}
                  className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-4 py-2.5 rounded-xl text-sm shadow-lg shadow-indigo-600/20 transition active:scale-95"
                >
                  <Plus className="w-4 h-4" />
                  افزودن متغیر و آدرس جدید
                </button>
              </div>

              {/* Variables Table */}
              <div className="bg-slate-900/40 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
                <div className="overflow-x-auto">
                  <table className="w-full text-right border-collapse">
                    <thead>
                      <tr className="bg-slate-900 border-b border-slate-800 text-slate-400 text-xs font-semibold">
                        <th className="p-4">نام متغیر</th>
                        <th className="p-4">آدرس تارگت</th>
                        <th className="p-4">عبارت منظم (Regex)</th>
                        <th className="p-4 text-center">بازه آپدیت (دقیقه)</th>
                        <th className="p-4 text-center">آخرین وضعیت</th>
                        <th className="p-4 text-center">آخرین بروزرسانی</th>
                        <th className="p-4 text-left">عملیات</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 text-sm text-slate-300">
                      {variables.map((v) => (
                        <tr key={v.id} className="hover:bg-slate-900/20 transition-colors">
                          <td className="p-4">
                            <div className="font-bold text-slate-200">{v.name}</div>
                            <div className="text-[11px] text-slate-500 font-mono mt-0.5">{v.id}</div>
                          </td>
                          <td className="p-4 max-w-xs truncate">
                            <a 
                              href={v.url} 
                              target="_blank" 
                              rel="noreferrer" 
                              className="text-indigo-400 hover:underline flex items-center gap-1 font-mono text-xs"
                            >
                              {v.url}
                              <ExternalLink className="w-3 h-3 shrink-0" />
                            </a>
                          </td>
                          <td className="p-4 font-mono text-xs text-indigo-300">
                            <code>{v.regex}</code>
                          </td>
                          <td className="p-4 text-center font-mono">
                            هر {v.interval} دقیقه
                          </td>
                          <td className="p-4 text-center">
                            <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${
                              v.lastStatus === "success"
                                ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                                : v.lastStatus === "failed"
                                ? "bg-rose-500/10 text-rose-400 border border-rose-500/20"
                                : "bg-slate-800 text-slate-400 border border-slate-700"
                            }`}>
                              <span className={`h-1.5 w-1.5 rounded-full ${
                                v.lastStatus === "success" ? "bg-emerald-400" : v.lastStatus === "failed" ? "bg-rose-400" : "bg-slate-400"
                              }`} />
                              {v.lastStatus === "success" ? "موفق" : v.lastStatus === "failed" ? "خطا" : "آی‌دل"}
                            </span>
                          </td>
                          <td className="p-4 text-center text-xs font-mono text-slate-400">
                            {v.lastScraped 
                              ? new Date(v.lastScraped).toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" }) 
                              : "نچرخیده"}
                          </td>
                          <td className="p-4 text-left">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => openQuickTestModal(v)}
                                className="p-1.5 hover:bg-slate-800 rounded-lg text-amber-400 hover:text-amber-300 transition"
                                title="تست استخراج داده"
                              >
                                <Play className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => openEditModal(v)}
                                className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-indigo-400 transition"
                                title="ویرایش الگو"
                              >
                                <Edit className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteVariable(v.id)}
                                className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-rose-400 transition"
                                title="حذف متغیر"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}

                      {variables.length === 0 && (
                        <tr>
                          <td colSpan={7} className="p-8 text-center text-slate-500 bg-slate-900/10">
                            هیچ موردی ثبت نشده است. دکمه افزودن متغیر جدید را فشار دهید.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </motion.div>
          )}

          {/* TAB 3: GITHUB & API GUIDE */}
          {activeTab === "guide" && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6 max-w-4xl mx-auto"
            >
              
              {/* GitHub Flow Guide */}
              <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-xl">
                    <Github className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-100 text-lg">راه‌اندازی بدون سرور در بستر گیت‌هاب (Serverless)</h3>
                    <p className="text-xs text-slate-400 mt-0.5">اسکرایپ قیمت‌ها و خدمات API کاملاً رایگان با استفاده از GitHub Actions</p>
                  </div>
                </div>

                <div className="text-sm text-slate-300 leading-relaxed space-y-3">
                  <p>
                    این پروژه به گونه‌ای طراحی شده است که بدون نیاز به هیچ سرور یا هاست پولی، بتواند به صورت مداوم قیمت‌ها را استخراج کند! 
                    روال کار بدین صورت است:
                  </p>
                  <ol className="list-decimal list-inside space-y-2 pr-2 text-slate-400 text-xs">
                    <li>کد پروژه را در یک مخزن (Repository) اختصاصی در گیت‌هاب آپلود (Push) کنید.</li>
                    <li>موتور <strong>GitHub Actions</strong> طبق برنامه زمانی منظمی که در فایل <code className="text-indigo-400">scraper.yml</code> تعیین کرده‌اید، به صورت خودکار بیدار می‌شود.</li>
                    <li>کدهای پایتون (<code className="text-indigo-400">scraper.py</code>) اجرا شده و داده‌های جدید را استخراج می‌کند و آنها را داخل فایل‌های JSON گیت‌هاب ثبت می‌نماید.</li>
                    <li>داده‌های آپدیت شده مجدداً کامیت شده و روی هاست گیت‌هاب ذخیره می‌شوند و شما می‌توانید فایل <code className="text-indigo-400">prices.json</code> را به عنوان یک <strong>API آدرس ایستا (Static API)</strong> در تمام وب‌سایت‌ها فراخوانی کنید!</li>
                  </ol>
                </div>

                {/* Workflow Code snippet */}
                <div className="space-y-2">
                  <span className="text-xs text-slate-400 block font-medium">فایل گردش‌کار ایجاد شده در پروژه:</span>
                  <div className="relative bg-slate-950 p-4 rounded-xl border border-slate-800/80 font-mono text-xs overflow-x-auto text-left ltr">
                    <pre className="text-slate-300">
{`name: Price Scraper Cron Job
on:
  schedule:
    - cron: '0 * * * *' # بیدار شدن خودکار هر یک ساعت یک‌بار
jobs:
  scrape-and-commit:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v4
    - uses: actions/setup-python@v5
    - run: pip install requests
    - run: python scraper.py
    - name: Push Back to Repo
      run: |
        git config --global user.name "scraper-bot"
        git add src/data/*.json
        git commit -m "chore: auto-update prices"
        git push`}
                    </pre>
                  </div>
                </div>
              </div>

              {/* API Consumption Playground */}
              <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-xl">
                    <Globe className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-100 text-lg">راهنمای فراخوانی داده‌ها در سایر وب‌سایت‌ها (API Endpoints)</h3>
                    <p className="text-xs text-slate-400 mt-0.5">نحوه ارتباط و دریافت داده‌های استخراج شده برای وب‌اپلیکیشن‌ها</p>
                  </div>
                </div>

                {/* Method Toggles */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  {/* Dynamic Express Server API */}
                  <div className="bg-slate-950/60 p-5 rounded-xl border border-slate-800 space-y-3">
                    <div className="flex items-center gap-2">
                      <Database className="w-4 h-4 text-indigo-400" />
                      <h4 className="font-bold text-xs text-slate-200">روش اول: سرور پویا (Express API)</h4>
                    </div>
                    <p className="text-slate-400 text-xs leading-relaxed">
                      اگر پروژه را روی سرور شخصی یا داکر مستقر کنید، یک وب‌سرویس فعال خواهید داشت که داده‌های لحظه‌ای را به صورت زنده ارائه می‌دهد.
                    </p>
                    <div className="bg-indigo-500/10 text-indigo-400 px-2 py-1 rounded text-[11px] font-mono select-all inline-block ltr">
                      GET {window.location.origin}/api/prices
                    </div>
                    
                    <div className="relative">
                      <button 
                        onClick={() => handleCopyCode(apiFetchSnippet, "js-fetch")}
                        className="absolute top-2 left-2 p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-200 transition"
                      >
                        {copiedTextId === "js-fetch" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                      <pre className="p-3 bg-slate-950 border border-slate-900 rounded-lg text-[10px] font-mono text-slate-300 overflow-x-auto text-left ltr pt-8">
                        {apiFetchSnippet}
                      </pre>
                    </div>
                  </div>

                  {/* Serverless GitHub API */}
                  <div className="bg-slate-950/60 p-5 rounded-xl border border-slate-800 space-y-3">
                    <div className="flex items-center gap-2">
                      <Github className="w-4 h-4 text-purple-400" />
                      <h4 className="font-bold text-xs text-slate-200">روش دوم: گیت‌هاب بدون سرور (Static CDN)</h4>
                    </div>
                    <p className="text-slate-400 text-xs leading-relaxed">
                      شما نیازی به اجرای سرور ندارید! فقط کافیست به فایل‌های JSON که به صورت خودکار روی ریپوزیتوری گیت‌هاب آپلود می‌شوند متصل شوید.
                    </p>
                    <div className="bg-purple-500/10 text-purple-400 px-2 py-1 rounded text-[11px] font-mono select-all inline-block ltr">
                      GET https://raw.githubusercontent.com/.../prices.json
                    </div>

                    <div className="relative">
                      <button 
                        onClick={() => handleCopyCode(githubStaticSnippet, "gh-static")}
                        className="absolute top-2 left-2 p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-200 transition"
                      >
                        {copiedTextId === "gh-static" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                      <pre className="p-3 bg-slate-950 border border-slate-900 rounded-lg text-[10px] font-mono text-slate-300 overflow-x-auto text-left ltr pt-8">
                        {githubStaticSnippet}
                      </pre>
                    </div>
                  </div>

                </div>

                {/* Python Snippet */}
                <div className="bg-slate-950/40 border border-slate-800 p-4 rounded-xl space-y-2">
                  <h4 className="text-xs font-bold text-slate-200">نمونه کد فراخوانی در پایتون (Python API Client):</h4>
                  <div className="relative">
                    <button 
                      onClick={() => handleCopyCode(pythonFetchSnippet, "py-snippet")}
                      className="absolute top-2 left-2 p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-200 transition"
                    >
                      {copiedTextId === "py-snippet" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                    <pre className="p-3 bg-slate-950 border border-slate-900 rounded-lg text-[11px] font-mono text-slate-300 overflow-x-auto text-left ltr pt-8">
                      {pythonFetchSnippet}
                    </pre>
                  </div>
                </div>

              </div>

            </motion.div>
          )}

        </div>

      </div>

      {/* FOOTER */}
      <footer className="mt-16 border-t border-slate-900 py-6 max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
        <div>پلتفرم هوشمند استخراج و پایش قیمت‌ها با پایتون + ری‌اکت</div>
        <div className="flex items-center gap-1 font-mono">
          <span>v1.0.0</span>
          <span>•</span>
          <span>سازگار با گیت‌هاب اکشنز و سرورهای توزیع‌شده</span>
        </div>
      </footer>

      {/* MODAL FORM FOR ADDING / EDITING VARIABLE */}
      <AnimatePresence>
        {showFormModal && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto p-6 md:p-8 space-y-6 shadow-2xl"
            >
              <div className="flex justify-between items-center border-b border-slate-800 pb-4">
                <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                  <Settings className="w-5 h-5 text-indigo-400" />
                  {editingVar ? `ویرایش الگو: ${editingVar.name}` : "افزودن متغیر و الگوی استخراج جدید"}
                </h3>
                <button
                  onClick={() => setShowFormModal(false)}
                  className="p-1 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-100 transition"
                >
                  <XCircle className="w-6 h-6" />
                </button>
              </div>

              {/* Grid Form and Tester Side-by-side */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                
                {/* Form Fields Column */}
                <form onSubmit={handleSaveVariable} className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-xs text-slate-400 font-bold block">نام متغیر قیمتی</label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: قیمت انس جهانی طلا"
                      value={formData.name}
                      onChange={(e) => {
                        setFormData({ ...formData, name: e.target.value });
                        // Update tester variables concurrently for convenience
                        if (!editingVar) setTestRegex(formData.regex);
                      }}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-slate-100 focus:outline-none focus:border-indigo-500 transition"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs text-slate-400 font-bold block">آدرس وب‌سایت مرجع (URL)</label>
                    <input
                      type="url"
                      required
                      placeholder="https://example.com/gold-price"
                      value={formData.url}
                      onChange={(e) => {
                        setFormData({ ...formData, url: e.target.value });
                        setTestUrl(e.target.value);
                      }}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-slate-100 font-mono text-left ltr focus:outline-none focus:border-indigo-500 transition"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-xs text-slate-400 font-bold block">بازه آپدیت زمانی (دقیقه)</label>
                      <input
                        type="number"
                        required
                        min={5}
                        placeholder="60"
                        value={formData.interval}
                        onChange={(e) => setFormData({ ...formData, interval: parseInt(e.target.value) || 60 })}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-slate-100 font-mono focus:outline-none focus:border-indigo-500 transition"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs text-slate-400 font-bold block">واحد پولی / ارز داده</label>
                      <input
                        type="text"
                        placeholder="تومان، ریال، $"
                        value={formData.currency}
                        onChange={(e) => setFormData({ ...formData, currency: e.target.value })}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-slate-100 focus:outline-none focus:border-indigo-500 transition"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs text-slate-400 font-bold block">عبارت منظم برای صید اطلاعات (Regex)</label>
                    <input
                      type="text"
                      required
                      placeholder='class="price">([^<]+)'
                      value={formData.regex}
                      onChange={(e) => {
                        setFormData({ ...formData, regex: e.target.value });
                        setTestRegex(e.target.value);
                      }}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-indigo-300 font-mono text-left ltr focus:outline-none focus:border-indigo-500 transition"
                    />
                    <span className="text-[10px] text-slate-500 block">
                      داده استخراج شده نهایی باید در داخل اولین پرانتز صید شود (مانند <code className="text-slate-400 font-mono">([a-zA-Z0-9.,]+)</code>).
                    </span>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs text-slate-400 font-bold block">توضیح کوتاه</label>
                    <textarea
                      placeholder="منبع و نوع استفاده..."
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-sm text-slate-100 h-16 focus:outline-none focus:border-indigo-500 transition"
                    />
                  </div>

                  <div className="flex items-center gap-3 py-2">
                    <input
                      type="checkbox"
                      id="active"
                      checked={formData.active}
                      onChange={(e) => setFormData({ ...formData, active: e.target.checked })}
                      className="w-4 h-4 bg-slate-950 border-slate-800 text-indigo-500 rounded focus:ring-indigo-500"
                    />
                    <label htmlFor="active" className="text-sm font-semibold text-slate-300">متغیر فعال باشد (پایش به صورت دوره‌ای انجام شود)</label>
                  </div>

                  <div className="flex gap-3 pt-4 border-t border-slate-800">
                    <button
                      type="submit"
                      className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 rounded-xl transition active:scale-95 animate-none"
                    >
                      {editingVar ? "ذخیره تغییرات" : "ایجاد متغیر جدید"}
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowFormModal(false)}
                      className="px-6 bg-slate-800 hover:bg-slate-700 text-slate-300 py-3 rounded-xl transition"
                    >
                      انصراف
                    </button>
                  </div>
                </form>

                {/* REGEX TESTER COLUMN */}
                <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 flex flex-col justify-between">
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <Code className="w-5 h-5 text-amber-400" />
                      <h4 className="font-bold text-sm text-slate-200">شبیه‌ساز و تستر زنده عبارت منظم (Regex Sandbox)</h4>
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      قبل از نهایی کردن متغیر، الگوی عبارت منظم خود را به صورت زنده روی سایت تارگت تست کنید تا از استخراج دقیق اطلاعات مطمئن شوید!
                    </p>

                    <div className="space-y-3 pt-2">
                      <div className="space-y-1">
                        <span className="text-[11px] text-slate-500 block">آدرس وب‌سایت برای تست:</span>
                        <input
                          type="text"
                          placeholder="https://example.com"
                          value={testUrl}
                          onChange={(e) => setTestUrl(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-left ltr focus:outline-none"
                        />
                      </div>

                      <div className="space-y-1">
                        <span className="text-[11px] text-slate-500 block">عبارت منظم برای تست:</span>
                        <input
                          type="text"
                          placeholder='class="price">([^<]+)'
                          value={testRegex}
                          onChange={(e) => setTestRegex(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-left ltr text-amber-300 focus:outline-none"
                        />
                      </div>

                      <button
                        type="button"
                        onClick={handleTestRegex}
                        disabled={isTestingRegex}
                        className="w-full bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/20 font-bold py-2 rounded-xl text-xs transition flex items-center justify-center gap-1.5"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${isTestingRegex ? "animate-spin" : ""}`} />
                        {isTestingRegex ? "در حال فراخوانی و ارزیابی..." : "تست زنده الگو روی سایت هدف"}
                      </button>
                    </div>

                    {/* Result Output */}
                    <AnimatePresence>
                      {testResult && (
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className={`p-4 rounded-xl border text-xs space-y-2 mt-4 ${
                            testResult.success
                              ? "bg-emerald-500/5 border-emerald-500/20 text-emerald-400"
                              : "bg-rose-500/5 border-rose-500/20 text-rose-400"
                          }`}
                        >
                          <div className="flex items-center gap-1.5 font-bold">
                            {testResult.success ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                            <span>{testResult.message}</span>
                          </div>

                          {testResult.success && (
                            <div className="space-y-1 pt-1.5 border-t border-emerald-500/10">
                              <div>
                                <span className="text-slate-400 block mb-0.5">کل عبارت منطبق شده:</span>
                                <code className="bg-slate-900 px-2 py-1 rounded block overflow-x-auto text-slate-200 text-left ltr font-mono">
                                  {testResult.match}
                                </code>
                              </div>
                              <div className="pt-1.5">
                                <span className="text-slate-400 block mb-0.5">مقدار استخراج شده (گروه اول پرانتز):</span>
                                <code className="bg-slate-900 px-2 py-1 rounded block text-amber-300 text-left ltr font-mono font-bold text-sm">
                                  {testResult.capturedGroup}
                                </code>
                              </div>
                            </div>
                          )}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  <div className="pt-4 border-t border-slate-900 text-[11px] text-slate-500 flex items-start gap-1.5">
                    <Info className="w-4 h-4 shrink-0 text-slate-600 mt-0.5" />
                    <span>
                      این ابزار با ایجاد پروکسی امن روی سرور، محتوای صفحه مورد نظر را دانلود کرده و عبارت منظم شما را به صورت زنده تست می‌کند.
                    </span>
                  </div>
                </div>

              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* QUICK TEST MODAL FOR EXISTING VARIABLE */}
      <AnimatePresence>
        {showTestModal && testingVar && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl"
            >
              <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-950/40">
                <div className="flex items-center gap-2">
                  <Play className="w-5 h-5 text-amber-400" />
                  <h3 className="text-base font-bold text-slate-100">تست دریافت و استخراج داده</h3>
                </div>
                <button
                  onClick={() => setShowTestModal(false)}
                  className="text-slate-500 hover:text-slate-300 transition text-lg"
                >
                  ✕
                </button>
              </div>

              <div className="p-6 space-y-4">
                <div className="space-y-1">
                  <span className="text-[11px] text-slate-500 block">نام متغیر:</span>
                  <div className="text-sm font-bold text-slate-200">{testingVar.name}</div>
                </div>

                <div className="space-y-1">
                  <span className="text-[11px] text-slate-500 block">آدرس وب‌سایت:</span>
                  <a
                    href={testingVar.url}
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs text-indigo-400 font-mono block truncate hover:underline"
                  >
                    {testingVar.url}
                  </a>
                </div>

                <div className="space-y-1">
                  <span className="text-[11px] text-slate-500 block">عبارت منظم برای صید داده:</span>
                  <code className="text-xs text-indigo-300 font-mono block bg-slate-950 p-2 rounded border border-slate-800">
                    {testingVar.regex}
                  </code>
                </div>

                {/* Status or Result block */}
                <div className="pt-2">
                  {isQuickTesting ? (
                    <div className="bg-slate-950/40 border border-slate-800 rounded-xl p-6 flex flex-col items-center justify-center gap-3 text-center">
                      <RefreshCw className="w-6 h-6 text-indigo-400 animate-spin" />
                      <span className="text-xs text-slate-400">در حال اتصال به سرور هدف و بررسی الگو...</span>
                    </div>
                  ) : quickTestResult ? (
                    <div
                      className={`p-4 rounded-xl border text-xs space-y-3 ${
                        quickTestResult.success
                          ? "bg-emerald-500/5 border-emerald-500/20 text-emerald-400"
                          : "bg-rose-500/5 border-rose-500/20 text-rose-400"
                      }`}
                    >
                      <div className="flex items-center gap-1.5 font-bold">
                        {quickTestResult.success ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                        <span>{quickTestResult.message}</span>
                      </div>

                      {quickTestResult.success && (
                        <div className="space-y-2 pt-2 border-t border-emerald-500/10">
                          <div>
                            <span className="text-slate-400 block mb-0.5">کل عبارت منطبق شده:</span>
                            <code className="bg-slate-950 px-2 py-1 rounded block overflow-x-auto text-slate-200 text-left ltr font-mono">
                              {quickTestResult.match}
                            </code>
                          </div>
                          <div>
                            <span className="text-slate-400 block mb-0.5">مقدار استخراج شده (گروه اول):</span>
                            <code className="bg-slate-950 px-2.5 py-1.5 rounded block text-amber-300 text-left ltr font-mono font-bold text-sm">
                              {quickTestResult.capturedGroup}
                            </code>
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="bg-slate-950/40 border border-slate-800 rounded-xl p-4 text-center text-xs text-slate-500">
                      پاسخی دریافت نشد.
                    </div>
                  )}
                </div>
              </div>

              <div className="p-4 bg-slate-950/40 border-t border-slate-800 flex gap-3 justify-end">
                <button
                  onClick={() => runQuickTest(testingVar.url, testingVar.regex)}
                  disabled={isQuickTesting}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold px-4 py-2 rounded-lg transition disabled:opacity-50 flex items-center gap-1.5"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isQuickTesting ? "animate-spin" : ""}`} />
                  تلاش مجدد
                </button>
                <button
                  onClick={() => setShowTestModal(false)}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold px-4 py-2 rounded-lg transition"
                >
                  بستن
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
