export interface ScrapingVariable {
  id: string;
  name: string;
  url: string;
  regex: string;
  selector?: string;
  interval: number; // in minutes
  extractType: 'number' | 'text';
  currency: string;
  description?: string;
  active: boolean;
  lastScraped?: string;
  lastStatus: 'success' | 'failed' | 'idle';
  lastError?: string;
}

export interface PriceRecord {
  id: string;
  variableId: string;
  value: number;
  timestamp: string; // ISO String
  rawText?: string;
}

export interface AlertLog {
  id: string;
  variableId: string;
  variableName: string;
  oldValue: number;
  newValue: number;
  changePercent: number;
  timestamp: string;
}
